DIMENSION_NUM=40;
PIRTICLE_NUM=20;
TIME=100;
CIR_TIME=1000;
wa0=1.0;
wa1=0.5;
a0=0.7;
a1=0.1;
iter_temp = 0;
iter_total=20000;
P_REQUIRE=10500;
% pmin=[40  60  80 24 26   68 110 135 135 130    94  94 125 125 125   125 125 220 220 242   242 254 254 254 254   254 254  10  10  10   20 20 20 20 18   18 20 25 25 25 ];
% pmax=[80 120 190 42 42  140 300 300 300 300   375 375 500 500 500   500 500 500 500 550   550 550 550 550 550   550 550 150 150 150   70 70 70 70 60   60 60 60 60 60];
pmin = [36 36 60 80 47 68 110 135 135 130 94 94 125 125 125 125 220 220 242 242 254 254 254 254 254 254 10 10 10 47 60 60 60 90 90 90 25 25 25 242];
pmax = [114 114 120 190 97 140 300 300 300 300 375 375 500 500 500 500 500 500 550 550 550 550 550 550 550 550 150 150 150 97 190 190 190 200 200 200 110 110 110 550];
PENISH_COEFFICIENT=100;
t=1;
xmax=500;
L=2*xmax*sqrt(DIMENSION_NUM);
qpso_result=zeros(TIME,1);
allvaluetemp=0;
xtemp=zeros(CIR_TIME,1);
ytemp=zeros(CIR_TIME,1);
qpso_result_gbest_value=zeros(CIR_TIME,TIME);
qpso_result_gbest=zeros(CIR_TIME,TIME,DIMENSION_NUM);
div=zeros(CIR_TIME,TIME);
rau = ones(1,DIMENSION_NUM);
iter_sw = 2;
pc=0.1;
pm=0.1;
for time=1:TIME
    tic;
    p=rand(PIRTICLE_NUM,DIMENSION_NUM);
    for i=1:PIRTICLE_NUM
        for j=1 : DIMENSION_NUM
          p(i,j)=rand(1,1)*(pmax(j)-pmin(j))+pmin(j);
        end
    end;
    pbest=p;
    value=zeros(PIRTICLE_NUM,1);
    pbest_value=zeros(PIRTICLE_NUM,1);
    for i=1 : PIRTICLE_NUM
        value(i)=fvalue(pbest(i,:),t);
    end
    pbest_value=value;
    iter_temp = PIRTICLE_NUM;
    dtemp=1;
    valuetemp=pbest_value(1);
    for i=2 : PIRTICLE_NUM
        if valuetemp > pbest_value(i)
            dtemp=i;
            valuetemp=pbest_value(i);
        end
    end
    gbest=pbest(int32(dtemp),:);
    gbest_value=valuetemp;

    for cir_time=1 : CIR_TIME
        if iter_temp < iter_total

        mbest=sum(pbest)/PIRTICLE_NUM;    
        belt=(wa0-wa1)*(CIR_TIME-cir_time)/CIR_TIME+wa1;
        a=(a0-a1)*(CIR_TIME-cir_time)/CIR_TIME+a1;
        div=diversity(PIRTICLE_NUM,L,DIMENSION_NUM,pbest,mbest);
        for i=1:PIRTICLE_NUM
            
            fi=rand(1,DIMENSION_NUM);
            p1=fi.*pbest(i,:)+(1-fi).*gbest;
            u=log(1./rand(1,DIMENSION_NUM));
            r=ceil(0.5+rand(1,DIMENSION_NUM));
            p(i,:)=p1+belt*(-1).^r.*abs(mbest-p(i,:)).*u;
            for j=1:DIMENSION_NUM             
                if p(i,j)>pmax(j)
                    p(i,j)=pmax(j);
                end
                if p(i,j)<pmin(j)
                    p(i,j)=pmin(j);
                end
            end    
        end
        
        pl = rand();
        if cir_time > 1/2* CIR_TIME
        if pl > 0.5
            GApop=Cross(pc,DIMENSION_NUM,p,PIRTICLE_NUM,[pmin;pmax]');
            GApop=Mutation(pm,DIMENSION_NUM,GApop,PIRTICLE_NUM,[1 CIR_TIME],[pmin;pmax]');
            p=GApop; 
        end
        end
        pl_int = randi(PIRTICLE_NUM);

        [X_new, fv] = SW(p(pl_int,:),rau,4,4,iter_sw,cir_time,pmax,pmin);
                if gbest_value > fv
                    gbest=X_new;
                    gbest_value=fv;
                end
         p(pl_int,:) = X_new;
         iter_temp = iter_temp+iter_sw;
        for i=1:PIRTICLE_NUM
            value(i)=fvalue(p(i,:),t);        
            if value(i)<pbest_value(i)
                pbest_value(i)=value(i);
                pbest(i,:)=p(i,:);
            end
        end
        dtemp=1;
        valuetemp=pbest_value(1);
        for i=2 : PIRTICLE_NUM
            if valuetemp > pbest_value(i)
                dtemp=i;
                valuetemp=pbest_value(i);
            end;
        end;
        if gbest_value > valuetemp
            gbest=pbest(int32(dtemp),:);
            gbest_value=valuetemp;
        end;
        iter_temp = iter_temp+PIRTICLE_NUM;

        divtemp=diversity(PIRTICLE_NUM,L,DIMENSION_NUM,p,sum(p)/PIRTICLE_NUM);
        div(cir_time,time)=divtemp;
            qpso_result_gbest(cir_time,time,:)=gbest;
            qpso_result_gbest_value(cir_time,time)=gbest_value;
            ytemp(cir_time)=ytemp(cir_time)+gbest_value;
            xtemp(cir_time)=cir_time;
        else
            divtemp=diversity(PIRTICLE_NUM,L,DIMENSION_NUM,p,sum(p)/PIRTICLE_NUM);
            div(cir_time,time)=divtemp;
            qpso_result_gbest(cir_time,time,:)=gbest;
            qpso_result_gbest_value(cir_time,time)=gbest_value;
            ytemp(cir_time)=ytemp(cir_time)+gbest_value;
            xtemp(cir_time)=cir_time;  
        end
    end
    total_power=0.00;
    for i=1 : DIMENSION_NUM
        total_power=total_power+gbest(i);
    end;
    toc;
    qpso_result(time)=gbest_value;
    allvaluetemp=allvaluetemp+gbest_value;
end

clear;
        
        
    