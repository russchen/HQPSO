function div=diversity(S,L,D,P,Mbest)
N=P-ones(S,1)*Mbest;
Z=N.^2;
W=sum(Z');
div=sum(sqrt(W))/(S*L);

    


