function [X, fv] = SW(X,p,succ_max,fail_max,iter_max,t,pmax,pmin)
len = length(X);
b = zeros(1,len);
iter = 0;
succ = 0;
fail = 0;
while iter < iter_max
    for i=1:len
        D(i) = normrnd(b(i),p(i));
    end
    X_temp = X+D;
    for j=1 : len
        if X_temp(j)>pmax(j)
            X_temp(j)=pmax(j);
        end
        if X_temp(j)<pmin(j)
            X_temp(j)=pmin(j);
        end
    end
    if fvalue(X_temp,sqrt(t)) < fvalue(X,sqrt(t))
        X = X_temp;
        succ = succ+1;
        fail = 0;
        b = 0.4*b + 0.2*D;
    else
        X_temp = X - D;
        for j=1 : len
            if X_temp(j)>pmax(j)
                X_temp(j)=pmax(j);
            end
            if X_temp(j)<pmin(j)
                X_temp(j)=pmin(j);
            end
        end; 
        if fvalue(X_temp,sqrt(t)) < fvalue(X,sqrt(t))
            X = X_temp;
            succ = succ+1;
            fail = 0;
            b = b - 0.4*D;
        else
            fail = fail+1;
            succ = 0;
            b = 0.5*b;
        end
    end
    if succ == succ_max
        p = 2*p;
        succ=0;
    end
    if fail == fail_max
        p = 0.5*p;
        fail = 0;
    end
    iter = iter + 1;
end
fv = fvalue(X,sqrt(t));
end



